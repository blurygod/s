# main.py
import asyncio
import logging
import sys
import signal
from pathlib import Path

from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties

# Import from config
from config_bot import BOT_TOKEN, DEBUG, config as app_config, validate_config, MONGO_URI, MONGO_DB_NAME
from commands import router

# Import functions for cleanup
from functions.charge_functions import close_session
from functions.co_functions import close_parser_session

# Import MongoDB client and middleware - NEW
from database.mongo_client import MongoDBClient
from middleware.credit_check import CreditCheckMiddleware

# Configure logging
logging.basicConfig(
    level=logging.DEBUG if DEBUG else logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('bot.log', encoding='utf-8')
    ]
)

logger = logging.getLogger(__name__)

# Global variables
bot = None
dp = None
shutdown_event = asyncio.Event()

async def on_startup():
    """Actions to perform on bot startup"""
    logger.info("=" * 50)
    logger.info("🚀 XMAN Bot is starting up...")
    logger.info("=" * 50)
    
    # Validate configuration
    if not validate_config():
        logger.error("❌ Configuration validation failed!")
        return
    
    # Initialize MongoDB connection - NEW
    try:
        mongo = MongoDBClient(MONGO_URI, MONGO_DB_NAME)
        logger.info("✅ MongoDB connected successfully")
        
        # Test connection by pinging
        mongo.db.command('ping')
        logger.info("✅ MongoDB ping successful")
    except Exception as e:
        logger.error(f"❌ MongoDB connection failed: {e}")
        logger.warning("⚠️ Bot will continue but credit system may not work!")
        # Don't return - bot can still function with limited features
    
    logger.info("✅ Bot is ready to accept commands")
    logger.info(f"📊 Debug mode: {'ON' if DEBUG else 'OFF'}")
    logger.info("=" * 50)

async def on_shutdown():
    """Actions to perform on bot shutdown"""
    logger.info("=" * 50)
    logger.info("🛑 XMAN Bot is shutting down...")
    logger.info("=" * 50)
    
    # Cleanup charge functions session
    try:
        await close_session()
        logger.info("✅ Charge functions session closed")
    except Exception as e:
        logger.error(f"❌ Error closing charge session: {e}")
    
    # Cleanup co functions session
    try:
        await close_parser_session()
        logger.info("✅ Checkout parser session closed")
    except Exception as e:
        logger.error(f"❌ Error closing parser session: {e}")
    
    # Close MongoDB connection - NEW
    try:
        MongoDBClient().close()
        logger.info("✅ MongoDB connection closed")
    except Exception as e:
        logger.error(f"❌ Error closing MongoDB: {e}")
    
    # Close bot session
    if bot and bot.session:
        await bot.session.close()
        logger.info("✅ Bot session closed")
    
    logger.info("✅ Shutdown complete")
    shutdown_event.set()

def signal_handler(sig, frame):
    """Handle shutdown signals"""
    logger.info(f"📡 Received signal {sig}, initiating shutdown...")
    asyncio.create_task(on_shutdown())

async def main():
    """Main entry point"""
    global bot, dp
    
    try:
        # Validate bot token
        if not BOT_TOKEN:
            logger.error("❌ BOT_TOKEN is not set in config.py!")
            return
        
        # Initialize bot with HTML parse mode
        bot = Bot(
            token=BOT_TOKEN,
            default=DefaultBotProperties(parse_mode=ParseMode.HTML)
        )
        
        # Initialize dispatcher
        dp = Dispatcher()
        
        # Include router
        dp.include_router(router)
        
        # Add credit check middleware - NEW
        dp.message.middleware(CreditCheckMiddleware())
        
        # Register lifecycle hooks
        dp.startup.register(on_startup)
        dp.shutdown.register(on_shutdown)
        
        # Set up signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
        
        logger.info("🔄 Starting polling...")
        
        # Start polling with error handling
        await dp.start_polling(
            bot,
            skip_updates=True,
            allowed_updates=['message', 'callback_query']
        )
        
    except KeyboardInterrupt:
        logger.info("⌨️ Keyboard interrupt received")
        await on_shutdown()
        
    except Exception as e:
        logger.error(f"❌ Fatal error in main: {e}", exc_info=True)
        await on_shutdown()
        
    finally:
        # Wait for shutdown to complete
        try:
            await asyncio.wait_for(shutdown_event.wait(), timeout=10.0)
        except asyncio.TimeoutError:
            logger.warning("⚠️ Shutdown timed out")
        
        logger.info("👋 Bot stopped")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("👋 Bot stopped by user")
    except Exception as e:
        logger.error(f"💥 Unhandled exception: {e}", exc_info=True)
        sys.exit(1)