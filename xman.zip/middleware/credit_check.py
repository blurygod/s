# middleware/credit_check.py
from aiogram import BaseMiddleware
from aiogram.types import Message
from typing import Callable, Dict, Any, Awaitable
import logging

from database.repositories import UserRepository
from config_bot import OWNER_ID
from functions.proxy_utils import check_access

logger = logging.getLogger(__name__)

# Commands that don't require credits and should work for everyone
FREE_COMMANDS = [
    "/start", "/help", "/gen", ".gen", "/genhelp",
    "/redeem", "/balance", "/buy", "/bininfo", "/stopbco"
]

# Admin-only commands (also free but require admin)
ADMIN_COMMANDS = [
    "/adduser", "/removeuser", "/users", "/stats",
    "/broadcast", "/logs", "/restart", 
    "/generate", "/rmcode", "/codes", "/addcredits"
]

class CreditCheckMiddleware(BaseMiddleware):
    """Middleware to check if user has enough credits"""
    
    async def __call__(
        self,
        handler: Callable[[Message, Dict[str, Any]], Awaitable[Any]],
        event: Message,
        data: Dict[str, Any]
    ) -> Any:
        # Skip if not a message or no text
        if not event.text:
            return await handler(event, data)
        
        # Get command (first word)
        command = event.text.split()[0].lower()
        
        # DEBUG: Log the command and user
        print(f"[DEBUG] User {event.from_user.id} used command: {event.text[:50]}")
        
        # Always allow /start and /help for everyone (even without access)
        if command in ["/start", "/help"]:
            print(f"[DEBUG] Allowing {command} for everyone")
            return await handler(event, data)
        
        # Check if user is owner (always allowed)
        if event.from_user.id == OWNER_ID:
            print(f"[DEBUG] Owner detected, allowing all commands")
            return await handler(event, data)
        
        # Check if it's a free command - these should work for ANY user with access
        if command in FREE_COMMANDS:
            print(f"[DEBUG] Free command detected: {command}")
            # For free commands, we still need to check if user has basic access
            # But /redeem should work even for users without access
            if command == "/redeem":
                # /redeem should work for everyone to create account
                print(f"[DEBUG] Allowing /redeem for user {event.from_user.id}")
                return await handler(event, data)
            
            # For other free commands, check basic access
            if not check_access(event):
                await event.answer(
                    "❌ <b>Access Denied</b>\n\n"
                    "[🔗] Join to use: @XMANSPEAK",
                    parse_mode="HTML"
                )
                return
            return await handler(event, data)
        
        # For paid commands, check if user has basic access first
        if not check_access(event):
            await event.answer(
                "❌ <b>Access Denied</b>\n\n"
                "[🔗] Join to use: @XMANSPEAK",
                parse_mode="HTML"
            )
            return
        
        # Check if user exists and has credits
        user_repo = UserRepository()
        user = user_repo.get_user(event.from_user.id)
        
        if not user:
            # User exists in access control but not in MongoDB? Add them
            print(f"[DEBUG] User {event.from_user.id} not in MongoDB, adding...")
            user_repo.add_user(
                event.from_user.id,
                event.from_user.username,
                event.from_user.first_name,
                event.from_user.last_name
            )
            user = user_repo.get_user(event.from_user.id)
            
            if not user:
                await event.answer(
                    "[❌] <b>Error</b>\n\n"
                    "Could not create user account. Please contact support.",
                    parse_mode="HTML"
                )
                return
        
        # Check if user is admin (free)
        if user.get("is_admin", False):
            print(f"[DEBUG] Admin user detected, allowing all commands")
            return await handler(event, data)
        
        # Check if user is active
        if not user.get("is_active", False):
            print(f"[DEBUG] User {event.from_user.id} is inactive")
            await event.answer(
                "[❌] <b>Account Inactive</b>\n\n"
                "Your account is not active. Use /redeem to activate.\n"
                "Free commands: /start, /help, /gen, .gen, /genhelp, /redeem, /balance, /buy",
                parse_mode="HTML"
            )
            return
        
        credits = user.get("credits", 0)
        print(f"[DEBUG] User {event.from_user.id} has {credits} credits")
        
        if credits <= 0:
            await event.answer(
                "[❌] <b>Insufficient Credits</b>\n\n"
                f"You need credits to use {command}\n"
                f"Your balance: {credits}\n"
                "Use /buy to purchase credits or /redeem to redeem a code.\n\n"
                "Free commands: /start, /help, /gen, .gen, /genhelp, /redeem, /balance, /buy",
                parse_mode="HTML"
            )
            return
        
        # User has credits, proceed
        data["user_credits"] = credits
        print(f"[DEBUG] User {event.from_user.id} authorized to use {command}")
        return await handler(event, data)