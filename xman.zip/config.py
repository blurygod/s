# config.py
import os
import logging
from typing import Dict, Any, Optional
from pathlib import Path
from dataclasses import dataclass, field

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Bot Configuration
BOT_TOKEN = os.getenv("BOT_TOKEN", "8325903532:AAEPaja4ILLMOF-Xy373v2jRDXBZHqPqDxc")  # Replace with your token

# Group and user access
ALLOWED_GROUP = int(os.getenv("ALLOWED_GROUP", "-1002264347100"))
OWNER_ID = int(os.getenv("OWNER_ID", "7251204928"))

# File paths - using pathlib for cross-platform compatibility
BASE_DIR = Path(__file__).parent
PROXY_FILE = str(BASE_DIR / "proxies.json")
USER_FILE = str(BASE_DIR / "users.json")

# MongoDB Configuration - NEW
MONGO_URI = os.getenv("MONGO_URI", "mongodb+srv://blury:blury@cluster0.ahtbs9q.mongodb.net/?appName=Cluster0")
MONGO_DB_NAME = os.getenv("MONGO_DB_NAME", "xman_bot")

# Performance settings
MAX_CONCURRENT_CHARGES = int(os.getenv("MAX_CONCURRENT_CHARGES", "5"))
REQUEST_TIMEOUT = int(os.getenv("REQUEST_TIMEOUT", "25"))
CONNECT_TIMEOUT = int(os.getenv("CONNECT_TIMEOUT", "8"))
MAX_RETRIES = int(os.getenv("MAX_RETRIES", "3"))

# Stripe API Headers
HEADERS = {
    "accept": "application/json",
    "content-type": "application/x-www-form-urlencoded",
    "origin": "https://checkout.stripe.com",
    "referer": "https://checkout.stripe.com/",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "accept-language": "en-US,en;q=0.9",
}

# Currency symbols for display
CURRENCY_SYMBOLS = {
    "USD": "$", "EUR": "€", "GBP": "£", "INR": "₹", "JPY": "¥",
    "CNY": "¥", "KRW": "₩", "RUB": "₽", "BRL": "R$", "CAD": "C$",
    "AUD": "A$", "MXN": "MX$", "SGD": "S$", "HKD": "HK$", "THB": "฿",
    "VND": "₫", "PHP": "₱", "IDR": "Rp", "MYR": "RM", "ZAR": "R",
    "CHF": "CHF", "SEK": "kr", "NOK": "kr", "DKK": "kr", "PLN": "zł",
    "TRY": "₺", "AED": "د.إ", "SAR": "﷼", "ILS": "₪", "TWD": "NT$"
}

# Stripe Checkout specific settings
STRIPE_PK_KEY = os.getenv("STRIPE_PK_KEY", "pk_live_4kM0zYmj8RdKCEz9oaVNLhvl00GpRole3Q")
STRIPE_BASE_URL = os.getenv("STRIPE_BASE_URL", "https://www.propski.co.uk/")
BIN_API_URL = os.getenv("BIN_API_URL", "https://bins.antipublic.cc/bins/")

# Debug mode
DEBUG = os.getenv("DEBUG", "False").lower() == "true"

if DEBUG:
    logging.getLogger().setLevel(logging.DEBUG)
    logger.debug("Debug mode enabled")

# 3DS Bypass settings
BYPASS_METHODS = {
    "return_url": "return_url",
    "payment_intent": "payment_intent",
    "setup_future": "setup_future_usage",
    "off_session": "off_session",
    "manual": "manual",
    "incremental": "incremental"
}

@dataclass
class Config:
    """Configuration dataclass for type-safe access"""
    BOT_TOKEN: str = BOT_TOKEN
    ALLOWED_GROUP: int = ALLOWED_GROUP
    OWNER_ID: int = OWNER_ID
    PROXY_FILE: str = PROXY_FILE
    USER_FILE: str = USER_FILE
    MONGO_URI: str = MONGO_URI  # NEW
    MONGO_DB_NAME: str = MONGO_DB_NAME  # NEW
    MAX_CONCURRENT_CHARGES: int = MAX_CONCURRENT_CHARGES
    REQUEST_TIMEOUT: int = REQUEST_TIMEOUT
    CONNECT_TIMEOUT: int = CONNECT_TIMEOUT
    MAX_RETRIES: int = MAX_RETRIES
    HEADERS: Dict[str, str] = field(default_factory=lambda: HEADERS.copy())
    CURRENCY_SYMBOLS: Dict[str, str] = field(default_factory=lambda: CURRENCY_SYMBOLS.copy())
    DEBUG: bool = DEBUG
    BYPASS_METHODS: Dict[str, str] = field(default_factory=lambda: BYPASS_METHODS.copy())
    STRIPE_PK_KEY: str = STRIPE_PK_KEY
    STRIPE_BASE_URL: str = STRIPE_BASE_URL
    BIN_API_URL: str = BIN_API_URL

def validate_config() -> bool:
    """Validate configuration settings"""
    if not BOT_TOKEN:
        logger.error("❌ BOT_TOKEN is not set!")
        return False
    
    if len(BOT_TOKEN) < 10:
        logger.error("❌ BOT_TOKEN appears to be invalid!")
        return False
    
    logger.info(f"✅ Bot token loaded: {BOT_TOKEN[:10]}...")
    logger.info(f"✅ Allowed group: {ALLOWED_GROUP}")
    logger.info(f"✅ Owner ID: {OWNER_ID}")
    logger.info(f"✅ Proxy file: {PROXY_FILE} (JSON fallback)")
    logger.info(f"✅ Users file: {USER_FILE} (JSON fallback)")
    logger.info(f"✅ MongoDB URI: {MONGO_URI.split('@')[-1] if '@' in MONGO_URI else 'configured'}")  # NEW
    logger.info(f"✅ MongoDB Database: {MONGO_DB_NAME}")  # NEW
    logger.info(f"✅ Stripe PK Key: {STRIPE_PK_KEY[:15]}...")
    logger.info(f"✅ Stripe Base URL: {STRIPE_BASE_URL}")
    
    # Check if files exist, create if not (for backward compatibility)
    for file_path in [PROXY_FILE, USER_FILE]:
        if not os.path.exists(file_path):
            try:
                with open(file_path, 'w') as f:
                    if file_path.endswith('.json'):
                        f.write('{}')
                    else:
                        f.write('')
                logger.info(f"✅ Created missing file: {file_path}")
            except Exception as e:
                logger.error(f"❌ Failed to create {file_path}: {e}")
                # Don't return False, MongoDB will be primary storage
    
    return True

# Create config instance
config = Config()

# Validate on import
config_valid = validate_config()
if not config_valid:
    logger.warning("⚠️ Configuration validation failed. Check your settings.")

# Export commonly used items
__all__ = [
    'BOT_TOKEN',
    'ALLOWED_GROUP',
    'OWNER_ID',
    'PROXY_FILE',
    'USER_FILE',
    'MONGO_URI',  # NEW
    'MONGO_DB_NAME',  # NEW
    'HEADERS',
    'CURRENCY_SYMBOLS',
    'MAX_CONCURRENT_CHARGES',
    'REQUEST_TIMEOUT',
    'CONNECT_TIMEOUT',
    'MAX_RETRIES',
    'DEBUG',
    'BYPASS_METHODS',
    'STRIPE_PK_KEY',
    'STRIPE_BASE_URL',
    'BIN_API_URL',
    'config',
    'validate_config'
]